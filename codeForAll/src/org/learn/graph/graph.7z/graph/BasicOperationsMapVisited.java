package org.learn.graph;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

public class BasicOperationsMapVisited {
	public static AdjacencyListMapVisited buildGraph(int numberOfVertex) {
		AdjacencyListMapVisited graph = new AdjacencyListMapVisited();
		List<String> vertices = generateVertices(numberOfVertex);
		graph.addVertices(vertices);
		
		for (Entry<Vertex, List<Edge>> entry: graph.getVertices().entrySet()) {
			String currentVertex =  entry.getKey().getValue();
			while(entry.getValue().isEmpty()) {
			List<String> edges = randomEdges(vertices);
			for (Iterator<String> iterator = edges.iterator(); iterator.hasNext();) {
				String edge = (String) iterator.next();
				graph.addEdge(currentVertex, edge, generateRandomNumber());
				}
			}
		}
		return graph;
	}
		
	private static List<String> randomEdges(List<String> vertices){
		Random r = new Random();		

		//For generating random edge count for a vertex.
		int low = 0;
		int high = vertices.size();
		int randomVertexCount = r.nextInt(high-low) + low;
	
		int randomVertexIndex = -1;
		
		List<String> list = new ArrayList<String>(randomVertexCount);
		for(int i=1; i<=randomVertexCount; i++) {
			randomVertexIndex = r.nextInt(high-low) + low;
			if(list.contains(vertices.get(randomVertexIndex))) {
				i--;
				continue;
			}
			list.add(vertices.get(randomVertexIndex));
		}
		return list;
	}

	private static List<String> generateVertices(int vertexCount){
		List<String> vertices = new ArrayList<String>();
		
		Random r = new Random();
		//For generating random alphabets.
		int low = 1;
		int high = 26;
		char randomVertexAlphabet = 0;
				
		for(int i=1; i<=vertexCount; i++) {
			randomVertexAlphabet = (char) (65 + r.nextInt(high-low) + low);
			//In case a duplicate vertex is generated.
			if(vertices.contains(randomVertexAlphabet + "")) {
				i--;
				continue;
			}
			vertices.add(randomVertexAlphabet + "");
		}
		return vertices;
	}
	
	private static Integer generateRandomNumber() {
		Random random = new Random();
		int low = 1;
		int high = 100;
		return random.nextInt(high-low)+low;
	}
	
	public static String bfs(AdjacencyListMapVisited graph, String srcVertex) {
		if(!graph.isVertexPresent(srcVertex)) {
			System.out.println("Starting vertex of traversal not found. Aborting...");
			return "";
		}
		
		String output= "";
		Queue<Vertex> queue = new LinkedList<Vertex>();
		Vertex vrtx = new Vertex(srcVertex);
		graph.markVertexVisited(srcVertex);
		queue.add(vrtx);
		
		do {
			 vrtx = queue.remove();
			 output += vrtx.getValue() + " ";
			 List<Edge> edgeList = graph.retrieveEdgeList(vrtx.getValue());
			 for (Iterator iterator = edgeList.iterator(); iterator.hasNext();) {
				Edge edge = (Edge) iterator.next();
				if(graph.isVertexVisited(edge.getDestVertex()))
					continue;
				graph.markVertexVisited(edge.getDestVertex());
				queue.add(new Vertex(edge.getDestVertex()));
			}
		}while(!queue.isEmpty());
		return output;
	}
	
	public static String dfs(AdjacencyListMapVisited graph, String srcVertex) {
		if(!graph.isVertexPresent(srcVertex)) {
			System.out.println("Starting vertex of traversal not found. Aborting...");
			return "";
		}
		
		String output= "";
		Stack<Vertex> stack = new Stack<Vertex>();
		Vertex vrtx = new Vertex(srcVertex);
		graph.markVertexVisited(srcVertex);
		stack.add(vrtx);
		
		do {
			 vrtx = stack.pop();
			 //vrtx.setVisited(true);
			 output += vrtx.getValue() + " ";
			 List<Edge> edgeList = graph.retrieveEdgeList(vrtx.getValue());
			 for (Iterator iterator = edgeList.iterator(); iterator.hasNext();) {
				Edge edge = (Edge) iterator.next();
				if(graph.isVertexVisited(edge.getDestVertex()))
					continue;
				graph.markVertexVisited(edge.getDestVertex());
				stack.add(new Vertex(edge.getDestVertex()));
			}
		}while(!stack.isEmpty());
		return output;
	}
	
	public static List<Edge> kruskalsMinimumSpanningTree(AdjacencyListMapVisited graph) {
		int len = graph.getVertices().size();
		int minCost = -1;
		int totalCost = 0;
		Edge edge;
		List<Edge> edges = new ArrayList<Edge>();
		for(int i=0; i<len-1; i++) {//0 -> n-1
			edge = graph.findMinimumCostEdge(edges, new int[] {minCost});
			if(edge==null || edges.contains(edge)) {
				i--;
				if(edge==null)
				  edge.setCost(-1);
				continue;
			}
			edges.add(edge);
			if(detectCycle(edges)) {
				i--;
				edges.remove(edges.size()-1);
				edge.setCost(-1);
			}
			minCost = edge.getCost();
		}
		return edges;
	}
	
	public static boolean detectCycle(List<Edge> edges) {
		boolean visited[] = new boolean[edges.size()];		
		visited[visited.length-1] = true;
		Queue<Edge> queue =  new LinkedList<Edge>();
		Edge insertedEdge = edges.get(edges.size()-1);
		
		//for(int i=0; i<edges.size(); i++) {
			queue.add(insertedEdge);
			while(!queue.isEmpty()) {
				Edge edge = queue.remove();
				for(int k=0; k<edges.size(); k++) {
					//If its an existing edge.
					if(edges.get(k).equals(edge))
						continue;
					
					//Add all edges outgoing from edge's dest vertex.
					if(((edges.get(k).getSrcVertex().equals(edge.getDestVertex()) || edges.get(k).getDestVertex().equals(edge.getDestVertex())))){
						if(edges.get(k).getSrcVertex().equals(insertedEdge.getSrcVertex()) || edges.get(k).getDestVertex().equals(insertedEdge.getSrcVertex()))
							return true;
						//visited[k] = true;
						queue.add(edges.get(k));
					}
				}
			}
		//}
		return false;
	}
	
	public static AdjacencyListMapVisited getSampleGraph() {
		AdjacencyListMapVisited graph = new AdjacencyListMapVisited();
		List<String> vertices = new ArrayList<String>(7);
		vertices.add("A");
		vertices.add("B");
		vertices.add("C");
		vertices.add("D");
		vertices.add("E");
		vertices.add("F");
		vertices.add("G");
		graph.addVertices(vertices);
		
		List<Edge> edges = graph.getVertices().get(new Vertex("A"));
		Edge edge = new Edge("A", "B", 0);
		edges.add(edge);
		
		edge = new Edge("A", "C", 0);
		edges.add(edge);
		
		edges = graph.getVertices().get(new Vertex("B"));
		
		edge = new Edge("B", "D", 0);
		edges.add(edge);
		
		edge = new Edge("B", "E", 0);
		edges.add(edge);
		
        edges = graph.getVertices().get(new Vertex("C"));
		
		edge = new Edge("C", "F", 0);
		edges.add(edge);
		
		edge = new Edge("C", "G", 0);
		edges.add(edge);
		
		return graph;
	}
	
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		//Scanner scan = new Scanner(System.in);
//		System.out.println("Enter number of vertices in the graph :: ");
//		int verticesCount = scan.nextInt();
		//AdjacencyListMapVisited graph = BasicOperationsMapVisited.buildGraph(verticesCount);
		//ObjectInputStream ois = new ObjectInputStream(new FileInputStream("graph1.txt"));
		//AdjacencyListMapVisited graph = (AdjacencyListMapVisited) ois.readObject();
//		
//		ObjectInputStream oos = new ObjectInputStream(new FileInputStream("graph.txt"));
//		AdjacencyListMapVisited graph = (AdjacencyListMapVisited) oos.readObject();
//		System.out.println(graph);
		//System.out.println(graph);
//		String startVertex = graph.getRandomVertex().getValue();
//		System.out.println("Start Vertex:: " + startVertex);
//		System.out.println(BasicOperationsMapVisited.dfs(graph, startVertex));
		
		//System.out.println(graph);
//		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("graph1.txt"));
//		oos.writeObject(graph);
//		List<Edge> edges = BasicOperationsMapVisited.kruskalsMinimumSpanningTree(graph);
//		edges.forEach(edge->{
//			System.out.println(edge.getSrcVertex() + "--" + edge.getCost() + "--" + edge.getDestVertex());
//		});
		
		//graph = getSampleGraph();
		//System.out.println(graph);
		//System.out.println(BasicOperationsMapVisited.dfs(graph, "A").equals("A C G F B E D "));
		AdjacencyListMapVisited graph = getSampleGraph();
		//System.out.println(BasicOperationsMapVisited.dfs(graph, "A"));
		//List<Edge> edges = BasicOperationsMapVisited.kruskalsMinimumSpanningTree(graph);
//		edges.forEach(edge->{
//			System.out.println(edge.getSrcVertex() + "--" + edge.getCost() + "--" + edge.getDestVertex());
//		});
	}
}