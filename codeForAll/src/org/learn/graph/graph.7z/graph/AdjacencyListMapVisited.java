package org.learn.graph;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

public class AdjacencyListMapVisited implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Map<Vertex, List<Edge>> vertices;
	
	public void addVertices(List<String> vertexList) {
		this.vertices = new HashMap<Vertex, List<Edge>>(vertexList.size());
	
		vertexList.forEach(vertex ->{
			this.vertices.put(new Vertex(vertex), new ArrayList<Edge>());
		});
	}
	
	public boolean addEdge(String src, String dest, Integer cost) {
		if(src.equals(dest))
			return false;
		
		//If either source or destination vertex is not present, we can't proceed.

		if(!isVertexPresent(src) || !isVertexPresent(dest))
			return false;
		
		Edge newEdge = new Edge(src, dest, cost);
		List<Edge> edges = this.vertices.get(new Vertex(src));
		List<Edge> destEdges = this.vertices.get(new Vertex(dest));
		if(!destEdges.contains(newEdge) & !edges.contains(newEdge)) {
			edges.add(newEdge);
			return true;
		}
//		newEdge = new Edge(dest, src, cost);
//		edges = this.vertices.get(new Vertex(dest));
//		if(!edges.contains(newEdge))
//			edges.add(newEdge);
		
		return false;
	}

	public Boolean isVertexPresent(String vertex) {
		return this.vertices.containsKey(new Vertex(vertex));
	}	
	
	public Boolean isVertexVisited(String vertex) {
		for (Vertex key: this.vertices.keySet()) {
			if(key.getValue().equals(vertex))
				return key.getVisited();
		}
		return false;
	}
	
	public void markVertexVisited(String vertex) {
		for (Vertex key: this.vertices.keySet()) {
			if(key.getValue().equals(vertex))
				key.setVisited(true);
		}
	}
		
	public List<Edge> retrieveEdgeList(String srcNode) {
		if(!this.isVertexPresent(srcNode))
			return null;
		return this.vertices.get(new Vertex(srcNode));
	}
	
	public Vertex getRandomVertex() {
		Set<Vertex> vertices = this.vertices.keySet();
		Vertex vrtx = null;
		
		int low = 0;
		int high = vertices.size()-1;
		Random random= new Random();
		int indx = random.nextInt(high-low);
		for (Iterator iterator = vertices.iterator(); iterator.hasNext();) {
			Vertex vertex = (Vertex) iterator.next();
			if(low==indx) {
				vrtx = vertex;
				break;
			}
			low++;
		}
		return vrtx;
	}

	public Map<Vertex, List<Edge>> getVertices() {
		return vertices;
	}

	public void setVertices(Map<Vertex, List<Edge>> vertices) {
		this.vertices = vertices;
	}
	
	public Edge findMinimumCostEdge(List<Edge> edges, int... minValue) {
		int maxValue = Integer.MAX_VALUE;
		int minimumValue = 0;
		if(minValue[0]>0)
			minimumValue = minValue[0];
		
		Edge minEdge = null;
		
		for (Entry<Vertex, List<Edge>> entry: this.vertices.entrySet()) {
			for (Iterator iterator = entry.getValue().iterator(); iterator.hasNext();) {
				Edge edge = (Edge) iterator.next();
				if((edge.getCost()>=minimumValue && edge.getCost()<maxValue) && !edges.contains(edge)) {
					maxValue = edge.getCost();
					minEdge = edge;
				}
			}
		}
		return minEdge;
	}
	
	public String toString() {
		String output = "";
		for (Entry<Vertex, List<Edge>> entry : vertices.entrySet()) {
			output += "(" + entry.getKey().getValue() + ")";
		    List<Edge> edges = entry.getValue();
		    if(edges.isEmpty())
		    	continue;
		    
		    int i=0;
		    for (; i<edges.size()-1; i++) {
				output += "--" + edges.get(i).getCost() + "-->" + "(" + edges.get(i).getDestVertex() + ")";// +  edges.get(i).getCost() + "--> ";
			}
		    output +=  "--" + edges.get(i).getCost() + "-->" +  "(" + edges.get(i).getDestVertex() + ")\n";
		}
		return output;
	}
}