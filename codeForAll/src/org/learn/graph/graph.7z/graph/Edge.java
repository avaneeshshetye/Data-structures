package org.learn.graph;

import java.io.Serializable;

public class Edge implements Serializable{
	private String srcVertex;
	private String destVertex;
	private Integer cost;
	
	public Edge(String src, String dest, Integer cost) {
		this.srcVertex = src;
		this.destVertex = dest;
		this.cost = cost;
	}	
	
	public String getDestVertex() {
		return destVertex;
	}

	public void setDestVertex(String destVertex) {
		this.destVertex = destVertex;
	}

	public Integer getCost() {
		return cost;
	}
	public void setCost(Integer cost) {
		this.cost = cost;
	}
	
	@Override
	public boolean equals(Object obj) {
		return this.destVertex.equals(((Edge) obj).getDestVertex()) && this.srcVertex.equals(((Edge) obj).getSrcVertex())
				|| this.srcVertex.equals(((Edge) obj).getDestVertex()) && this.destVertex.equals(((Edge) obj).getSrcVertex());
	}

	public String getSrcVertex() {
		return srcVertex;
	}

	public void setSrcVertex(String srcVertex) {
		this.srcVertex = srcVertex;
	}
}