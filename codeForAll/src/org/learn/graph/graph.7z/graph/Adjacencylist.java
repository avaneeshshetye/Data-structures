package org.learn.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Adjacencylist {
	
	List<Node> vertices;
	
	public void addVertices(List<String> vertexList) {
		this.vertices = new ArrayList<Node>(vertexList.size());
	
		vertexList.forEach(vertex ->{
			this.vertices.add(new Node(vertex, 0));
		});
	}
	
	public boolean addEdge(String src, String dest, Integer cost) {
		int srcVertexIndx = this.isVertexPresent(src);
		int destVertexIndx = this.isVertexPresent(dest);
		
		//If either source or destination vertex is not present, we can't proceed.
		if(srcVertexIndx<0 || destVertexIndx<0)
			return false;
		
		Node vertex = this.vertices.get(srcVertexIndx);	
		while(vertex.getNext()!=null)
			vertex = vertex.getNext();
		
		vertex.setNext(new Node(dest, cost));
		return true;
	}
	
	public boolean removeEdge(String src, String dest) {
		int srcVertexIndx = this.isVertexPresent(src);
		int destVertexIndx = this.isVertexPresent(dest);
		
		//If either source or destination vertex is not present, we can't proceed.
		if(srcVertexIndx<0 || destVertexIndx<0)
			return false;
		
		Node vertex = this.vertices.get(srcVertexIndx);
		do{
			if(vertex.getNext().getValue().equals(dest)) {
				vertex.setNext(vertex.getNext().getNext());
				return true;
			}
			vertex = vertex.getNext();
		}while(vertex.getNext()!=null);
		
		return false;
	}
	
	private int isVertexPresent(String vertex) {
		for(int i=0; i<this.vertices.size(); i++) {
			if(this.vertices.get(i).getValue().equals(vertex))
				return i;
		}
		return -1;
	}
	
	public String toString() {
		String output = "";
		for (Iterator iterator = vertices.iterator(); iterator.hasNext();) {
			Node node = (Node) iterator.next();
			while(node.getNext()!=null) {
				output += "(" + node.getValue() + ") --" + node.getCost() + "--> ";
				node = node.getNext();
			}
			output += "(" + node.getValue() + ")\n";
		}
		return output;
	}
	
	public List<Node> getNodeList() {
		return vertices;
	}

	public void setNodeList(List<Node> nodeList) {
		this.vertices = nodeList;
	}
}