package org.learn.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class BasicOperations {
	public static Adjacencylist buildGraph(int numberOfVertex) {
		Adjacencylist graph = new Adjacencylist();
		List<String> vertices = generateVertices(numberOfVertex);
		graph.addVertices(vertices);
		
		for(int i=0; i<numberOfVertex; i++) {
			List<String> edges = randomEdges(vertices);
			Node currentVertex =  graph.getNodeList().get(i);
			for (Iterator<String> iterator = edges.iterator(); iterator.hasNext();) {
				String edge = (String) iterator.next();
				graph.addEdge(currentVertex.getValue(), edge, generateRandomNumber());
			}
		}
		return graph;
	}
	
	public static void bfs(Adjacencylist graph) {
		
	}
	
	private static List<String> randomEdges(List<String> vertices){
		Random r = new Random();		

		//For generating random edge count for a vertex.
		int low = 1;
		int high = vertices.size();
		int randomVertexCount = r.nextInt(high-low) + low;
	
		int randomVertexIndex = -1;
		
		List<String> list = new ArrayList<String>(randomVertexCount);
		for(int i=1; i<=randomVertexCount; i++) {
			randomVertexIndex = r.nextInt(high-low) + low;
			if(list.contains(vertices.get(randomVertexIndex))) {
				i--;
				continue;
			}
			list.add(vertices.get(randomVertexIndex));
		}
		return list;
	}

	private static List<String> generateVertices(int vertexCount){
		List<String> vertices = new ArrayList<String>();
		
		Random r = new Random();
		//For generating random alphabets.
		int low = 1;
		int high = 26;
		char randomVertexAlphabet = 0;
				
		for(int i=1; i<=vertexCount; i++) {
			randomVertexAlphabet = (char) (65 + r.nextInt(high-low) + low);
			//In case a duplicate vertex is generated.
			if(vertices.contains(randomVertexAlphabet + "")) {
				i--;
				continue;
			}
			vertices.add(randomVertexAlphabet + "");
		}
		return vertices;
	}
	
	private static Integer generateRandomNumber() {
		Random random = new Random();
		int low = 1;
		int high = 100;
		return random.nextInt(high-low)+low;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter number of vertices in the graph :: ");
		int verticesCount = scan.nextInt();
		Adjacencylist graph = BasicOperations.buildGraph(verticesCount);
		System.out.println(graph);
	}
}