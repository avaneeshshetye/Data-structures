package org.learn.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class AdjacencyListMap {
	
	private Map<String, List<Edge>> vertices;
	
	public void addVertices(List<String> vertexList) {
		this.vertices = new HashMap<String, List<Edge>>(vertexList.size());
	
		vertexList.forEach(vertex ->{
			this.vertices.put(vertex, new ArrayList<Edge>());
		});
	}
	
	public boolean addEdge(String src, String dest, Integer cost) {
		//If either source or destination vertex is not present, we can't proceed.
		if(!isVertexPresent(src) || !isVertexPresent(dest))
			return false;
		
		Edge newEdge = new Edge(src, dest, cost);
		List<Edge> edges = this.vertices.get(src);
		edges.add(newEdge);
		return true;
	}

	private Boolean isVertexPresent(String vertex) {
		return this.vertices.containsKey(vertex);
	}
	
	public Map<String, List<Edge>> getVertices() {
		return vertices;
	}

	public void setVertices(Map<String, List<Edge>> vertices) {
		this.vertices = vertices;
	}
	
	public String toString() {
		String output = "";
		for (Entry<String, List<Edge>> entry : vertices.entrySet()) {
			output += "(" + entry.getKey() + ")";
		    List<Edge> edges = entry.getValue();
		    if(edges.isEmpty())
		    	continue;
		    
		    int i=0;
		    for (; i<edges.size()-1; i++) {
				output += "--" + edges.get(i).getCost() + "-->" + "(" + edges.get(i).getDestVertex() + ")";// +  edges.get(i).getCost() + "--> ";
			}
		    output +=  "--" + edges.get(i).getCost() + "-->" +  "(" + edges.get(i).getDestVertex() + ")\n";
		}
		return output;
	}
}