package org.learn.graph;

public class Node {
	private String value;
	private Node next;
	private Integer cost;

	public Node(String value, Integer cost) {
		this.value = value;
		this.cost = cost;
	}
	
	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Node getNext() {
		return next;
	}
	public void setNext(Node next) {
		this.next = next;
	}
	
	@Override
	public int hashCode() {
		return  Character.getNumericValue(this.getValue().toCharArray()[0]);
	}
	
	@Override
	public boolean equals(Object node) {
		return this.getValue().equals(((Node) node).getValue());
	}
}