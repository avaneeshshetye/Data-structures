package org.learn.graph;

import java.io.Serializable;

public class Vertex implements Serializable{
	private String value;
	private Vertex next;
	private boolean visited;

	public Boolean getVisited() {
		return visited;
	}

	public void setVisited(Boolean visited) {
		this.visited = visited;
	}

	public Vertex(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Vertex getNext() {
		return next;
	}
	public void setNext(Vertex next) {
		this.next = next;
	}
	
	@Override
	public int hashCode() {
		return  Character.getNumericValue(this.getValue().toCharArray()[0]);
	}
	
	@Override
	public boolean equals(Object node) {
		return this.getValue().equals(((Vertex) node).getValue());
	}
}